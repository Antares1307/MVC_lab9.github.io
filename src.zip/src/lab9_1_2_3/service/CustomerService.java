package lab9_1_2_3.service;

import java.util.List;

import lab9_1_2_3.entity.Customer;

public interface CustomerService {
	public List<Customer> getCustomers();
}
