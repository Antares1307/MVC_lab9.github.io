package lab9_1_2_3.dao;

import java.util.List;

import lab9_1_2_3.entity.Customer;

public interface CustomerDAO {
	public List<Customer> getCustomers();
}
