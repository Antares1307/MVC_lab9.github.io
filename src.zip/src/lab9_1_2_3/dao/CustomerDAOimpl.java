package lab9_1_2_3.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import lab9_1_2_3.entity.Customer;

@Repository
public class CustomerDAOimpl implements CustomerDAO {

	// need to inject the session factory
	@Autowired
	private SessionFactory sessionFactory;
	
	@Override
	@Transactional   // chuyển Transaction đến CustomerServiceImpl của lab9_1_2_3.service
	public List<Customer> getCustomers() {
		
		// Lấy ra phiên làm việc hiện tại của session.
		Session currentSession = sessionFactory.getCurrentSession();
		
		// Tạo ra câu lệnh truy vấn.
		Query<Customer> theQuery = 
				currentSession.createQuery("from Customer", Customer.class);
		
		// Thực hiện câu lệnh truy vấn và trả về một List danh sách.
		List<Customer> customers = theQuery.getResultList();
		
		// Trả về kết quả. tương ứng với trả về đối tượng Customer.
		return customers;
	}

}



// lab9.11 + 9.12
//@Repository
//public class CustomerDAOimpl implements CustomerDAO {
//
//	// need to inject the session factory
//	@Autowired
//	private SessionFactory sessionFactory;
//	
//	@Override
//	public List<Customer> getCustomers() {
//		
//		// Lấy ra phiên làm việc hiện tại của session.
//		Session currentSession = sessionFactory.getCurrentSession();
//		
//		// Tạo ra câu lệnh truy vấn.
//		Query<Customer> theQuery = 
//				currentSession.createQuery("from Customer", Customer.class);
//		
//		// Thực hiện câu lệnh truy vấn và trả về một List danh sách.
//		List<Customer> customers = theQuery.getResultList();
//		
//		// Trả về kết quả. tương ứng với trả về đối tượng Customer.
//		return customers;
//	}
//
//}





