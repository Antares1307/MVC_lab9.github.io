package lab9_1_2_3.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import lab9_1_2_3.dao.CustomerDAO;
import lab9_1_2_3.entity.Customer;
import lab9_1_2_3.service.CustomerService;


//@Controller
//@RequestMapping("/customer")
//public class CustomerController {
//
//	// need to inject the customer dao
//	@Autowired
//	private CustomerDAO customerDAO;
//	
//	@RequestMapping("/list")	
//	// lab 9.10
////	@GetMapping("/list")
////	@PostMapping("/list")
//	
//	public String listCustomers(Model theModel) {
//		
//		// get customers from the dao
//		List<Customer> theCustomers = customerDAO.getCustomers();
//				
//		// add the customers to the model
//		theModel.addAttribute("customers", theCustomers);
//		
//		return "list-customers";
//	}
//	
//}






// lab 9.11 + 9.12
@Controller
@RequestMapping("/customer")
public class CustomerController {

	// need to inject the customer dao
	@Autowired
	private CustomerService customerService;
	
	@GetMapping("/list")
	public String listCustomers(Model theModel) {
		
		// get customers from the dao
		List<Customer> theCustomers = customerService.getCustomers();
				
		// add the customers to the model
		theModel.addAttribute("customers", theCustomers);
		
		return "list-customers";
	}
	
}
















